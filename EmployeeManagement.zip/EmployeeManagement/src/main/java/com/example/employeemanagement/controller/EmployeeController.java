package com.example.employeemanagement.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.employeemanagement.entity.Employee;
import com.example.employeemanagement.service.EmployeeService;

@Controller
public class EmployeeController {

    @Autowired
    private EmployeeService service;

    @GetMapping("/")
    public String home() {
        return "home";
    }

    @GetMapping("/create")
    public String createPage() {
        return "create";
    }

    @PostMapping("/save")
    public String saveEmployee(@ModelAttribute Employee emp,
                               @RequestParam("action") String action) {

        service.saveEmployee(emp);

        if(action.equals("yes")) {
            return "create";
        }

        return "redirect:/";
    }

    @GetMapping("/display")
    public String display(Model model) {

        model.addAttribute("employees", service.getAllEmployees());

        return "display";
    }

    @GetMapping("/raise")
    public String raisePage() {
        return "raise";
    }

}