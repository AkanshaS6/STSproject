package com.example.employeemanagement.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.employeemanagement.entity.Employee;
import com.example.employeemanagement.repository.EmployeeRepository;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository repo;

    // Save Employee
    public Employee saveEmployee(Employee emp) {

        if (emp.getDesignation().equalsIgnoreCase("Programmer")) {
            emp.setSalary(25000);
        } 
        else if (emp.getDesignation().equalsIgnoreCase("Tester")) {
            emp.setSalary(20000);
        } 
        else if (emp.getDesignation().equalsIgnoreCase("Manager")) {
            emp.setSalary(30000);
        }

        return repo.save(emp);
    }

    // Display All Employees
    public List<Employee> getAllEmployees() {
        return repo.findAll();
    }

    // Raise Salary
    public void raiseSalary(int id, double amount) {

        Optional<Employee> optional = repo.findById(id);

        if (optional.isPresent()) {

            Employee emp = optional.get();

            emp.setSalary(emp.getSalary() + amount);

            repo.save(emp);
        }
    }
}